package com.mycompany.aula20250312classeteste;

public class Aula20250312ClasseTeste {

    public static void main(String[] args) {
        
        System.out.println("TESTES");
        
        Teste t1 = new Teste(40,50,60);
        Teste t2 = new Teste();

        
        /*t1.ImprimeA();
        t1.ImprimeB();
        t1.ImprimeC();
        System.out.println(t1.getC());*/

        System.out.println(Teste.quantidade);
    }
}
